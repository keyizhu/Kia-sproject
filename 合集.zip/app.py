import poplib
from email import policy
from email.parser import BytesParser
from email.header import decode_header, make_header
from bs4 import BeautifulSoup
from flask import Flask, request, render_template
import pickle

app = Flask(__name__)

# 加载训练好的垃圾邮件检测模型
with open('spam_classifier.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

# 加载保存的TF-IDF向量器
with open('tfidf_vectorizer.pkl', 'rb') as vec_file:
    vectorizer = pickle.load(vec_file)

# 从QQ邮箱读取邮件并提取正文内容
def get_html_payload(email_message):
    if email_message.is_multipart():
        for part in email_message.iter_parts():
            content_type = part.get_content_type()
            if content_type == 'text/html':
                html_content = part.get_content()
                return clean_html(html_content)
            elif content_type == 'text/plain':
                text_content = part.get_content()
                return text_content
    elif email_message.get_content_type() == 'text/html':
        html_content = email_message.get_content()
        return clean_html(html_content)
    elif email_message.get_content_type() == 'text/plain':
        text_content = email_message.get_content()
        return text_content

def clean_html(html_content):
    """去除HTML标签，提取纯文本内容"""
    soup = BeautifulSoup(html_content, "html.parser")
    return soup.get_text()

# 连接到POP3服务器，读取邮件内容
def fetch_emails():
    pop_server = poplib.POP3_SSL('pop.qq.com', 995) # 这个是固定的你不用管
    pop_server.user('2124909069@qq.com')  # 你的qq邮箱
    pop_server.pass_('ovbriwoarrcfbjhh')  # 换成你的授权码

    num_emails = len(pop_server.list()[1])
    email_details = []

    # 遍历每封邮件并提取正文
    for i in range(num_emails):
        response, lines, octets = pop_server.retr(i + 1)
        email_content = b'\r\n'.join(lines)

        # 解析邮件内容
        email_parser = BytesParser(policy=policy.default)
        email = email_parser.parsebytes(email_content)

        # 提取正文内容
        body = get_html_payload(email)

        email_details.append({
            "id": i,
            "body": body,
            "result": "Not checked"  # 初始化检测结果
        })

    pop_server.quit()
    return email_details

# 首页路由
@app.route('/')
def index():
    email_details = fetch_emails()
    return render_template('emails.html', emails=email_details)

# 手动输入检测页面
@app.route('/manual_detect', methods=['GET', 'POST'])
def manual_detect():
    result = None
    if request.method == 'POST':
        email_content = request.form['email_content']
        email_tfidf = vectorizer.transform([email_content])
        prediction = model.predict(email_tfidf)
        result = "Spam" if prediction[0] == 'spam' else "Normal email"
    return render_template('manual_detect.html', prediction_text=result)

# 检测选中的垃圾邮件
@app.route('/detect_spam', methods=['POST'])
def detect_spam():
    email_ids = request.form.getlist('email_ids')  # 获取选中的邮件ID列表
    auto_detect = request.form.get('auto_detect')  # 检查是否启用自动检测
    email_details = fetch_emails()
    detected_emails = []

    # 检查所有邮件或选中的邮件
    for email in email_details:
        if auto_detect == 'true' or str(email["id"]) in email_ids:
            email_tfidf = vectorizer.transform([email["body"]])
            prediction = model.predict(email_tfidf)
            email["result"] = "Spam" if prediction[0] == 'spam' else "Normal email"
        detected_emails.append(email)

    return render_template('emails.html', emails=detected_emails)

if __name__ == "__main__":
    app.run(debug=True)
