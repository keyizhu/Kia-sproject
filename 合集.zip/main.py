# 导入所需的库
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import pickle

# 加载数据
data = pd.read_csv('train.csv')

# 将数据分为特征 (X) 和标签 (y)
X = data['Email']
y = data['Label']

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 使用TF-IDF向量化文本内容
vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)  # 限制最大特征数
X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)

# 创建各个模型
nb_model = MultinomialNB()
log_reg = LogisticRegression(max_iter=1000)
svc = SVC(probability=True)
random_forest = RandomForestClassifier()

# 训练单个模型并输出其性能
models = {
    'Naive Bayes': nb_model,
    'Logistic Regression': log_reg,
    'SVC': svc,
    'Random Forest': random_forest
}

model_performance = {}

for name, model in models.items():
    model.fit(X_train_tfidf, y_train)
    y_pred = model.predict(X_test_tfidf)
    acc = accuracy_score(y_test, y_pred)
    model_performance[name] = acc

# 创建复合模型 (Voting Classifier) 软投票
voting_clf = VotingClassifier(estimators=[
    ('nb', nb_model),
    ('lr', log_reg),
    ('svc', svc),
    ('rf', random_forest)
], voting='soft')

# 训练复合模型
voting_clf.fit(X_train_tfidf, y_train)

# 在测试集上进行预测
y_pred_voting = voting_clf.predict(X_test_tfidf)

# 输出复合模型的准确率和分类报告
accuracy_voting = accuracy_score(y_test, y_pred_voting)
report_voting = classification_report(y_test, y_pred_voting)

# 输出复合模型的准确率和分类报告
print(f'复合模型的准确率: {accuracy_voting}')
print('复合模型的分类报告:')
print(report_voting)

# 输出混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred_voting)
print("混淆矩阵:")
print(conf_matrix)

# 保存模型
with open('spam_classifier.pkl', 'wb') as file:
    pickle.dump(voting_clf, file)

with open('spam_classifier.pkl', 'rb') as file:
    loaded_model = pickle.load(file)
    # 保存模型和向量器
with open('spam_classifier.pkl', 'wb') as model_file:
    pickle.dump(voting_clf, model_file)

with open('tfidf_vectorizer.pkl', 'wb') as vec_file:
    pickle.dump(vectorizer, vec_file)

print("模型和向量器已保存。")

sample_email = ["Congratulations! You've won a free iPhone! Click here to claim your prize."]
sample_email_tfidf = vectorizer.transform(sample_email)
sample_prediction = loaded_model.predict(sample_email_tfidf)

print(f"示例邮件的预测结果: {sample_prediction}")
